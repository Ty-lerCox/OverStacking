import { Component } from '@angular/core';
import { IonicPage } from 'ionic-angular';


@IonicPage()
@Component({
  selector: 'page-fab',
  templateUrl: 'fab.html'
})
export class FabPage {

    constructor( ) {
     
    }


}
