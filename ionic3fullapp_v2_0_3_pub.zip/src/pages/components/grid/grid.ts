import { Component } from '@angular/core';
import { IonicPage } from 'ionic-angular';

/*
  Generated class for the Search page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@IonicPage()
@Component({
  selector: 'page-grid',
  templateUrl: 'grid.html'
})
export class GridPage {

    constructor() {
  
    }
}
