import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Create1Page } from './create1';

@NgModule({
  declarations: [
    Create1Page,
  ],
  imports: [
    IonicPageModule.forChild(Create1Page),
  ],
})
export class Create1PageModule {}
