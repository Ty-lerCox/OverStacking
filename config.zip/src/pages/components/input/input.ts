import { Component } from '@angular/core';
import { IonicPage, NavController } from 'ionic-angular';

/*
  Generated class for the Search page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@IonicPage()
@Component({
  selector: 'page-input',
  templateUrl: 'input.html'
})
export class InputPage {

    constructor(public navCtrl: NavController ) {
  
    }



}
