import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { UpdateFeedbackPage } from './update-feedback';

@NgModule({
  declarations: [
    UpdateFeedbackPage,
  ],
  imports: [
    IonicPageModule.forChild(UpdateFeedbackPage),
  ],
})
export class UpdateFeedbackPageModule {}
