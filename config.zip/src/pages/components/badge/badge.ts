import { Component } from '@angular/core';
import { IonicPage, NavController } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-badge',
  templateUrl: 'badge.html'
})
export class BadgePage {

    constructor(public navCtrl: NavController ) {
  
    }

}
